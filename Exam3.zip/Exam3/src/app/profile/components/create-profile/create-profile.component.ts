import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CreateProfile } from '../../models/create-profile';
import { ProfileService } from '../../services/profile.service';

@Component({
  selector: 'app-create-profile',
  templateUrl: './create-profile.component.html',
  styleUrls: ['./create-profile.component.css'],
})
export class CreateProfileComponent implements OnInit {
  createProfile: CreateProfile = new CreateProfile();

  constructor(private profileService: ProfileService, private router: Router) {}

  createProfileSubmit() {
    this.profileService.createProfile(this.createProfile).subscribe(
      (res) => {
        console.log('success');
        this.router.navigate(['/dashboard/dashboard-actions']);
        console.log(JSON.stringify(res.token));
        localStorage.setItem('token', res.token);
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
  }

  ngOnInit(): void {}
}
