import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileRoutingModule } from './profile-routing.module';
import { CreateProfileComponent } from './components/create-profile/create-profile.component';
import { HttpInterceptorProviders } from '../core/interceptors';
import { ProfileService } from './services/profile.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [CreateProfileComponent],
  imports: [CommonModule, HttpClientModule, FormsModule, ProfileRoutingModule],
  providers: [HttpInterceptorProviders, ProfileService],
})
export class ProfileModule {}
