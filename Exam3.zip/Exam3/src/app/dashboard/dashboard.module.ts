import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { HttpClientModule } from '@angular/common/http';
import { HttpInterceptorProviders } from '../core/interceptors';
import { AuthService } from '../auth/services/auth.service';
import { ProfileService } from '../profile/services/profile.service';
import { DashboardActionsComponent } from './components/dashboard-actions/dashboard-actions.component';

@NgModule({
  declarations: [DashboardComponent, DashboardActionsComponent],
  imports: [CommonModule, HttpClientModule, DashboardRoutingModule],
  providers: [HttpInterceptorProviders, ProfileService, AuthService],
})
export class DashboardModule {}
