import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreRoutingModule } from './core-routing.module';
import { NavbarComponent } from './components/layouts/navbar/navbar.component';
import { LandingComponent } from './components/layouts/landing/landing.component';
import { FooterComponent } from './components/layouts/footer/footer.component';
import { HttpInterceptorProviders } from './interceptors';

@NgModule({
  declarations: [NavbarComponent, LandingComponent, FooterComponent],
  imports: [CommonModule, CoreRoutingModule],
  providers: [HttpInterceptorProviders],
  exports: [NavbarComponent, LandingComponent, FooterComponent],
})
export class CoreModule {}
