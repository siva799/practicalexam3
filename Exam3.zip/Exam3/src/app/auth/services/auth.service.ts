import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private http: HttpClient) {}

  registerUser(data: any): Observable<any> {
    return this.http.post('/api/users', data);
  }

  loginUser(data: any): Observable<any> {
    return this.http.post('/api/auth', data);
  }

  loadUser(): Observable<any> {
    return this.http.get('/api/auth');
  }
}
